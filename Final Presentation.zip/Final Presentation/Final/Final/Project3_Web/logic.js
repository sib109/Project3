function createMap(csvfile, mapnumber) {
  // Creating map object
  var myMap = L.map(mapnumber, {
    center: [0, 0],
    zoom: 1
  });

  var dataset = csvfile.slice(5,6);
  // var dataset = csvfile.slice(0, 1);
  console.log(dataset);

  // Adding tile layer
  L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
    attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
    maxZoom: 18,
    id: "mapbox.streets",
    accessToken: API_KEY
  }).addTo(myMap);

  // Link to GeoJSON
  // var url = "http://catalog.civicdashboards.com/dataset/1e6ed4b8-2694-4c6d-9ed8-e720e46b24d5/resource/bd37f9ed-337e-4eef-b88a-3b91172474f3/download/f303e5c67d254c5db93bb4ccdbb6e70fgeojsonmedianhouseholdincomecensustract.geojson";
  var url = "data/countries_final.geojson";

  function changeMapFunction(date) {
    var valueProperty = "data_" + date.label + "_" + date.dataset;
    console.log(valueProperty);
    var url = "data/countries_final.geojson";

    // Adding tile layer
    L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
      attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
      maxZoom: 18,
      id: "mapbox.streets",
      accessToken: API_KEY
    }).addTo(myMap);

    d3.json(url).then(function(JSONdata, err){

      countryData = JSONdata.features;

      var geojson;
      // start chloropleth map here
      geoJSON = L.choropleth(JSONdata, {

        // Define what  property in the features to use
        valueProperty: valueProperty,

        // Set color scale
        scale: ["#ffffb2", "#b10026"],

        // Number of breaks in step range
        steps: 10,

        // q for quartile, e for equidistant, k for k-means
        mode: "q",
        style: {
          // Border color
          color: "#fff",
          weight: 1,
          fillOpacity: 1
        }

      }).addTo(myMap);
    });

  }

  // Grab data with d3
  d3.json(url).then(function(JSONdata, err){

    L.control.timelineSlider({
              timelineItems: ["2012", "2005", "2000", "1996"],
              extraChangeMapParams: {dataset: dataset},
              changeMap: changeMapFunction})
          .addTo(myMap);

  });
}
