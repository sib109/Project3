
import csv
import pandas as pd

from flask import (
    Flask,
    render_template,
    jsonify,
    request)

from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

@app.route("/api/data/nourishment")
def list_nourishment():
    nourishment_db = pd.read_csv('1. Undernourished Population.csv')
    return (nourishment_db.to_json(orient='records'))

@app.route("/api/data/education")
def list_education():
    education_db = pd.read_csv('2. Education.csv')
    return (education_db.to_json(orient='records'))

@app.route("/api/data/gender")
def list_gender():
    gender_db = pd.read_csv('3. Gender Parity.csv')
    return (gender_db.to_json(orient='records'))

@app.route("/api/data/imr")
def list_imr():
    imr_db = pd.read_csv('4. Infant Mortality.csv')
    return (imr_db.to_json(orient='records'))

@app.route("/api/data/mmr")
def list_mmr():
    mmr_db = pd.read_csv('5. Maternal Mortality.csv')
    return (mmr_db.to_json(orient='records'))

@app.route("/api/data/tb")
def list_tb():
    tb_db = pd.read_csv('6. Tuberculosis.csv')
    return (tb_db.to_json(orient='records'))

@app.route("/api/data/sanitation")
def list_sanitation():
    sanitation_db = pd.read_csv('7. Sanitation.csv')
    return (sanitation_db.to_json(orient='records'))

@app.route("/api/data/imports")
def list_imports():
    imports_db = pd.read_csv('8. Imports.csv')
    return (imports_db.to_json(orient='records'))

@app.route("/")
def home():
    return render_template("index.html")


if __name__ == "__main__":
    app.run()
